#  Systemy czasu rzeczywistego, projekt zaliczeniowy numer 1. Piwowar Piotr i Marcin Czekaj
1. Zainstaluj NodeJS (https://nodejs.org/en/). Projekt tworzony był przy użyciu wersji 12.16.1.
2. Zainstaluj system kontroli wersji git.
3. Otwórz terminal/konsolę. 
4. Skopiuj wklej "git clone https://github.com/piwpio/SCR_Piwowar_Czekaj_project.git projekt_fabryka".
5. Przejdź do katalogu "projekt_fabryka".
6. Uruchom polecenie "npm install".
7. Po zainstalowaniu zależności uruchom polecenie "node index".
8. Otwórz przeglądarkę, przejdź pod adres "http://localhost:8080".
